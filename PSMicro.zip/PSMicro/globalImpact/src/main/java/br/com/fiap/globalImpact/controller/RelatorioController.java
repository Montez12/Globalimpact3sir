package br.com.fiap.globalImpact.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import br.com.fiap.globalImpact.model.RelatorioModel;
import br.com.fiap.globalImpact.repository.RelatorioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/globalImpact/relatorios")
public class RelatorioController {
    
    @Autowired
    private RelatorioRepository relatorioRepository;

    @GetMapping
    public ResponseEntity<List<RelatorioModel>> getAll() {

        List<RelatorioModel> result = relatorioRepository.findAll();

        return new ResponseEntity<>(result, HttpStatus.OK);
        
    }

    @PostMapping
    public ResponseEntity<RelatorioModel> post(@RequestBody @Valid RelatorioModel relatorio) {
        
        RelatorioModel relatorioSalvo = relatorioRepository.save(relatorio);

        return new ResponseEntity<RelatorioModel>(relatorioSalvo, HttpStatus.CREATED);

    }

    @PutMapping("/{id}")
    public ResponseEntity<RelatorioModel> updateById(@PathVariable String id, @RequestBody @Valid RelatorioModel relatorio) {

        Optional<RelatorioModel> relatorioOptional = relatorioRepository.findById(id);

        if(!relatorioOptional.isPresent()) {
            return new ResponseEntity<RelatorioModel>(HttpStatus.NOT_FOUND);
        }

        relatorio.setId(id);
        
        RelatorioModel relatorioSalvo = relatorioRepository.save(relatorio);

        return new ResponseEntity<RelatorioModel>(relatorioSalvo, HttpStatus.OK);

    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteById(@PathVariable String id) {

        relatorioRepository.deleteById(id);

    }

}
