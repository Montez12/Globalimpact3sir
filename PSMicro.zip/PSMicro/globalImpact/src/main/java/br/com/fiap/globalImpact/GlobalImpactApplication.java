package br.com.fiap.globalImpact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalImpactApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalImpactApplication.class, args);
	}

}
