package br.com.fiap.globalImpact.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.fiap.globalImpact.model.RelatorioModel;

public interface RelatorioRepository extends MongoRepository<RelatorioModel, String>{

}
