package br.com.fiap.globalImpact.model;

import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RelatorioModel {
    
    @Id
    private String id;
    @NotEmpty
    private String amostra;
    private Double ph;
    private Double temp;
    private String bacterias;
    private String eColi;
    private String cor;
    private String odor;

    public RelatorioModel() {
    }

    public RelatorioModel(@NotEmpty String amostra, Double ph, Double temp, String bacterias, String eColi,
            String cor, String odor) {
        this.amostra = amostra;
        this.ph = ph;
        this.temp = temp;
        this.bacterias = bacterias;
        this.eColi = eColi;
        this.cor = cor;
        this.odor = odor;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAmostra() {
        return amostra;
    }

    public void setAmostra(String amostra) {
        this.amostra = amostra;
    }

    public Double getPh() {
        return ph;
    }

    public void setPh(Double ph) {
        this.ph = ph;
    }

    public Double getTemp() {
        return temp;
    }

    public void setTemp(Double temp) {
        this.temp = temp;
    }

    public String getBacterias() {
        return bacterias;
    }

    public void setBacterias(String bacterias) {
        this.bacterias = bacterias;
    }

    public String geteColi() {
        return eColi;
    }

    public void seteColi(String eColi) {
        this.eColi = eColi;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getOdor() {
        return odor;
    }

    public void setOdor(String odor) {
        this.odor = odor;
    }

}
